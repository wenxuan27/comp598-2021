function fun1(){
  return 34
}